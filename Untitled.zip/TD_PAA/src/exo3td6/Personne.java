package exo3td6;
import java.util.List;
import java.util.ArrayList;
public class Personne {
	private String identifiant;

}
