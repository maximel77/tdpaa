package exo3td6;

public class main {
	public static void main(String args []) {
		Graphe <Integer> g= new Graphe<Integer>();
		g.ajouterNoeud(1);
		g.ajouterNoeud(2);
		g.ajouterNoeud(3);
		System.out.println(g.ajouterNoeud(4));
		System.out.println(g.ajouterNoeud(4));
		g.ajouterArc(1, 5);
		System.out.println(g.ajouterArc(3, 2));
		System.out.println(g.ajouterArc(3, 2));
		g.ajouterArc(3, 4);
		System.out.println(g);
	}

}
