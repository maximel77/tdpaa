package td3;
import java.util.Hashtable;
import java.util.ArrayList;
public class Etudiant {
	private String nom;
	private Hashtable<String,ArrayList<Integer>> noteUe;
	
	public Etudiant(String nom) {
		this.nom=nom;
		noteUe=new Hashtable<String,ArrayList<Integer>>();
	}
	public void

	
	

}
