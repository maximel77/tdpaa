package td3;

public class Personnage {
	
	private int pv;
	private int degat_attaque1;
	private int attaque1_restante;
	private int degat_attaque2;
	private int attaque2_restante;
	public Personnage(int p, int d1, int a1r, int d2, int a2r) {
		this.pv=p;
		this.degat_attaque1=d1;
		this.attaque1_restante=a1r;
		this.degat_attaque2=d2;
		this.attaque2_restante=a2r;
	}
	public  void perte_pv(int degat) {
		pv=pv-degat;
	}
	public int get_pv() {
		return pv;
	}
	public int get_degat_attaque1() {
		return degat_attaque1;
		
	}
	public int get_degat_attaque2() {
		return degat_attaque2;
	}
		
	public int  get_attaque1_restante() {
		return attaque1_restante;
	}
	public int  get_attaque2_restante() {
		return attaque2_restante;
	}
	public void attaque1_utiliser() {
		attaque1_restante-=1;
	}
	public void attaque2_utiliser() {
		attaque2_restante-=1;
	}
	public void attaque(Personnage p2, int  choix)	{
		if(choix==1) {
			p2.perte_pv(degat_attaque1);
		}
		else if(choix==2) {
			p2.perte_pv(degat_attaque2);
		} 
		
	}
	
	

}
