package td3;
import java .util.Scanner;
public class Joueur {
	Personnage p1;
	boolean humain;
	
	public Joueur(Personnage p,boolean h) {
		this.p1=p;
		this.humain=h;
	}
	public int choix() {
		boolean correct=false
		do {
			Scanner sc=new Scanner(System.in);
			System.out.println("choisissez une attaque(1) ou (2)");
			scanner
		}

	

}
